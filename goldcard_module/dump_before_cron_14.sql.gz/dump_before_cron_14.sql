--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Drop databases (except postgres and template1)
--

DROP DATABASE healthcare_db;




--
-- Drop roles
--

DROP ROLE kishok;


--
-- Roles
--

CREATE ROLE kishok;
ALTER ROLE kishok WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:r25HFz8GceXpYXDpGPlNCQ==$11N5kHM6SZQ8l/MHzyueEKwUBQtFgMRW7PEF/C10Axw=:GBQPLYr7d39EmEy2b8K2G+/WYNVsFon6eN/q8SxBPRI=';

--
-- User Configurations
--








--
-- Databases
--

--
-- Database "template1" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2 (Debian 16.2-1.pgdg120+2)
-- Dumped by pg_dump version 16.2 (Debian 16.2-1.pgdg120+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

UPDATE pg_catalog.pg_database SET datistemplate = false WHERE datname = 'template1';
DROP DATABASE template1;
--
-- Name: template1; Type: DATABASE; Schema: -; Owner: kishok
--

CREATE DATABASE template1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE template1 OWNER TO kishok;

\connect template1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: COMMENT; Schema: -; Owner: kishok
--

COMMENT ON DATABASE template1 IS 'default template for new databases';


--
-- Name: template1; Type: DATABASE PROPERTIES; Schema: -; Owner: kishok
--

ALTER DATABASE template1 IS_TEMPLATE = true;


\connect template1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: ACL; Schema: -; Owner: kishok
--

REVOKE CONNECT,TEMPORARY ON DATABASE template1 FROM PUBLIC;
GRANT CONNECT ON DATABASE template1 TO PUBLIC;


--
-- PostgreSQL database dump complete
--

--
-- Database "healthcare_db" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2 (Debian 16.2-1.pgdg120+2)
-- Dumped by pg_dump version 16.2 (Debian 16.2-1.pgdg120+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: healthcare_db; Type: DATABASE; Schema: -; Owner: kishok
--

CREATE DATABASE healthcare_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE healthcare_db OWNER TO kishok;

\connect healthcare_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: kishok
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO kishok;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: kishok
--

COMMENT ON SCHEMA public IS '';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cpt_code; Type: TABLE; Schema: public; Owner: kishok
--

CREATE TABLE public.cpt_code (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code character varying(10),
    description text,
    code_type character varying
);


ALTER TABLE public.cpt_code OWNER TO kishok;

--
-- Name: gold_carding_criteria; Type: TABLE; Schema: public; Owner: kishok
--

CREATE TABLE public.gold_carding_criteria (
    criteria_id uuid DEFAULT gen_random_uuid() NOT NULL,
    description character varying,
    metric character varying,
    threshold character varying,
    operator character varying,
    measurement_period_months integer,
    payer_id uuid,
    cpt_code character varying(10)
);


ALTER TABLE public.gold_carding_criteria OWNER TO kishok;

--
-- Name: gold_carding_evaluation_results; Type: TABLE; Schema: public; Owner: kishok
--

CREATE TABLE public.gold_carding_evaluation_results (
    evaluation_id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_id uuid,
    criteria_id uuid,
    evaluation_date timestamp without time zone,
    meets_criteria boolean,
    actual_value character varying
);


ALTER TABLE public.gold_carding_evaluation_results OWNER TO kishok;

--
-- Name: payer; Type: TABLE; Schema: public; Owner: kishok
--

CREATE TABLE public.payer (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying,
    description text
);


ALTER TABLE public.payer OWNER TO kishok;

--
-- Name: payer_gold_carding_eligibility; Type: TABLE; Schema: public; Owner: kishok
--

CREATE TABLE public.payer_gold_carding_eligibility (
    eligibility_id uuid DEFAULT gen_random_uuid() NOT NULL,
    payer_id uuid,
    provider_id uuid,
    cpt_code character varying(10),
    is_eligible boolean,
    reason text
);


ALTER TABLE public.payer_gold_carding_eligibility OWNER TO kishok;

--
-- Name: provider_cpt_approval; Type: TABLE; Schema: public; Owner: kishok
--

CREATE TABLE public.provider_cpt_approval (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_id uuid,
    cpt_code character varying(10),
    readmission boolean DEFAULT false NOT NULL,
    treatment_guideline_adherence boolean DEFAULT false NOT NULL,
    patient_satisfaction integer DEFAULT 0 NOT NULL,
    recovery_rate integer DEFAULT 0 NOT NULL,
    cost_efficiency integer DEFAULT 0 NOT NULL,
    submission_date timestamp without time zone,
    approval_status boolean,
    denial_reason text,
    payer_id uuid
);


ALTER TABLE public.provider_cpt_approval OWNER TO kishok;

--
-- Name: provider_cpt_metrics; Type: TABLE; Schema: public; Owner: kishok
--

CREATE TABLE public.provider_cpt_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_id uuid,
    cpt_code character varying(10),
    metric character varying,
    value character varying
);


ALTER TABLE public.provider_cpt_metrics OWNER TO kishok;

--
-- Name: provider_gold_carding_status; Type: TABLE; Schema: public; Owner: kishok
--

CREATE TABLE public.provider_gold_carding_status (
    status_id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_id uuid,
    criteria_met boolean,
    gold_carding_level character varying,
    valid_from timestamp without time zone,
    valid_until timestamp without time zone
);


ALTER TABLE public.provider_gold_carding_status OWNER TO kishok;

--
-- Name: providers; Type: TABLE; Schema: public; Owner: kishok
--

CREATE TABLE public.providers (
    provider_id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying,
    specialty character varying,
    npi_number character varying,
    email character varying,
    phone_number character varying
);


ALTER TABLE public.providers OWNER TO kishok;

--
-- Data for Name: cpt_code; Type: TABLE DATA; Schema: public; Owner: kishok
--

COPY public.cpt_code (id, code, description, code_type) FROM stdin;
ef645354-ab40-466a-b830-05c4362c2d62	99213	Office or other outpatient visit	OP
7e857485-1895-49b0-a8bf-b2aa38c4593c	99214	Detailed office or other outpatient visit	DOP
430ece3d-b3de-4ded-afe6-63605da6ba7a	93306	Echocardiography	ECHO
b575e0b9-4642-4432-8962-347d48acbb62	83036	Hemoglobin A1C level	HE
15014302-45d1-4c08-ab9e-bcfbebdf7671	12002	Simple wound repair	WR
32fdacda-f598-47c1-9181-52a612a04ebe	94321	MRI Body Scan	MRI
6f636865-6790-438b-9bd9-3295651a5467	95204	Therapy rehabilitation services	REH
e75e4083-2ad9-4055-a981-21fd91ec4101	96211	Diagnosis the Chronic Conditions	CDC
\.


--
-- Data for Name: gold_carding_criteria; Type: TABLE DATA; Schema: public; Owner: kishok
--

COPY public.gold_carding_criteria (criteria_id, description, metric, threshold, operator, measurement_period_months, payer_id, cpt_code) FROM stdin;
73527f9c-13b8-45bc-a477-0b7501a18662	Providers must have an approval rate of 100% or higher for all PA requests over the past 12 months.	approval_rate	100	\N	12	e7e0b516-e74e-4323-a086-532ede344fc0	94321
cb2ef014-00f9-4059-aad0-f35ceb835893	Providers must have 80% patient_satisfaction for treatment outcomes	patient_satisfaction	80	\N	12	7488d78c-a873-4cec-9196-ded89ac41773	95204
d1f53396-8433-4de2-b566-005fbce37bbe	Providers must demonstrate 90% recovery rate in rehabilitation services	recovery_rate	90	\N	12	7488d78c-a873-4cec-9196-ded89ac41773	95204
5bb64c2f-3a73-4f0a-87a3-fe41a459857f	Providers are required to show a 70% cost efficiency in their treatment methods, as well as in other clinical procedures.	cost_efficiency	70	\N	12	7488d78c-a873-4cec-9196-ded89ac41773	99214
de083923-7352-472f-999e-4920cd02c283	Providers must demonstrate 90% adherence to treatment guidelines for chronic conditions.	treatment_guideline_adherence	90	\N	12	7488d78c-a873-4cec-9196-ded89ac41773	96211
9ff788f5-52d7-4768-80ef-1a64262be2b0	Providers must have an approval rate of 95% or higher for all PA requests over the past 12 months.	approval_rate	95	\N	12	7488d78c-a873-4cec-9196-ded89ac41773	93306
c99e77bc-20f6-4aa6-805d-48487ee3433a	Readmission Rate ≤ 5% within 30 days.	readmission_rate	3	\N	1	e7e0b516-e74e-4323-a086-532ede344fc0	99213
f8d52b1d-1130-4b1e-a1e0-360d3820a511	Providers must have submitted at least 10 PA requests in the past 12 months.	submission_volume	10	\N	12	e7e0b516-e74e-4323-a086-532ede344fc0	93306
\.


--
-- Data for Name: gold_carding_evaluation_results; Type: TABLE DATA; Schema: public; Owner: kishok
--

COPY public.gold_carding_evaluation_results (evaluation_id, provider_id, criteria_id, evaluation_date, meets_criteria, actual_value) FROM stdin;
bd96b7e9-c975-4609-beed-1e788c2e3619	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	73527f9c-13b8-45bc-a477-0b7501a18662	2024-04-14 07:06:48.791	t	100
\.


--
-- Data for Name: payer; Type: TABLE DATA; Schema: public; Owner: kishok
--

COPY public.payer (id, name, description) FROM stdin;
e7e0b516-e74e-4323-a086-532ede344fc0	HealthyLife Insurance	Nationwide health insurance provider offering a range of healthcare plans.
7488d78c-a873-4cec-9196-ded89ac41773	WellCare Insurance	A leading health insurance company focused on preventive care and wellness.
\.


--
-- Data for Name: payer_gold_carding_eligibility; Type: TABLE DATA; Schema: public; Owner: kishok
--

COPY public.payer_gold_carding_eligibility (eligibility_id, payer_id, provider_id, cpt_code, is_eligible, reason) FROM stdin;
03a5d2e7-bdd9-4098-b6da-d301226c56ed	e7e0b516-e74e-4323-a086-532ede344fc0	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	t	\N
\.


--
-- Data for Name: provider_cpt_approval; Type: TABLE DATA; Schema: public; Owner: kishok
--

COPY public.provider_cpt_approval (id, provider_id, cpt_code, readmission, treatment_guideline_adherence, patient_satisfaction, recovery_rate, cost_efficiency, submission_date, approval_status, denial_reason, payer_id) FROM stdin;
8285b693-4f66-4524-ba00-4a5fc84d13bf	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2024-04-10 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
3e532ec5-2abe-4387-8fb1-baa0ab1b9648	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2023-02-28 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
828349be-b72c-47df-8887-f8cb3cda1b89	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2022-05-12 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
cdc6ed95-d578-4f70-96e0-ac94d86f0dc5	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2022-06-20 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
d73f53d6-f534-43b1-b58f-757e3893b67f	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2022-07-30 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
07fcef2a-d11e-4f10-81e6-c0353211c25c	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2022-02-10 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
fe2d13b8-2c2e-4374-a79c-58c42238f105	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2022-07-10 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
ca102a17-a3e5-4e3a-9c4e-21915e065161	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2022-07-20 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
15c56bae-01b5-48fe-83d3-9b6c4f6de8c4	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2022-07-01 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
098da28b-3500-4024-8dd9-c0c293c666d6	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2023-05-12 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
42812076-d44a-4391-8a04-e41ec5b8bae6	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2023-06-20 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
5e762e2b-55fc-4767-bbcb-b7f46ffa4cd7	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2023-07-14 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
d93032e4-4f35-45cb-9121-e7544e2221e4	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2023-08-10 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
e70578c6-ce10-441d-8994-8fa27a140a38	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2023-09-10 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
2b447d38-52bc-40f3-91b4-f63cda0529a8	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2023-10-20 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
96972c8a-330d-4dd4-baa3-84835febc27a	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2023-06-01 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
14ef69f0-628a-4a92-a068-8aff3a05c7e6	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2023-08-13 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
3f371196-ad77-493d-9a70-ef6a36ebcc95	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2023-11-22 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
7aab4110-2e4b-4a64-a158-e0c0d4866e84	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	93306	t	f	5	6	4	2023-03-15 00:00:00	t	\N	7488d78c-a873-4cec-9196-ded89ac41773
d5eed0b5-22e8-47ee-ae74-c59a10f1640e	b23fd4e2-2b0c-4e36-a481-e42e8d28e456	12002	t	f	3	2	3	2023-04-20 00:00:00	f	Incomplete documentation	7488d78c-a873-4cec-9196-ded89ac41773
aeafb71f-aafc-4a82-991f-25228ee66956	e89048b4-3f4d-4e5c-b6e4-7a0cf21366d2	99214	f	t	3	3	2	2023-05-10 00:00:00	f	Lack of prior necessary diagnosis	7488d78c-a873-4cec-9196-ded89ac41773
c9e25ba5-1755-4a57-8613-5404d92d60d7	a78601d4-8a0e-4961-a71e-eb2267c28934	99213	f	t	8	8	6	2023-06-05 00:00:00	t	\N	7488d78c-a873-4cec-9196-ded89ac41773
2e833dd0-7569-4da1-930a-f14f61bd858c	0f86bdea-6a4d-46a7-99d3-98146b019384	83036	t	t	8	7	8	2023-07-12 00:00:00	t	\N	7488d78c-a873-4cec-9196-ded89ac41773
d3af92de-8726-4d8f-bcb9-376d14709824	6cfbc032-2e94-43e0-94e2-8625e1a3b5b7	93306	f	f	7	6	2	2023-08-30 00:00:00	f	Out of policy coverage	7488d78c-a873-4cec-9196-ded89ac41773
8f668e62-0cbc-4009-be49-dbf22418c1e5	cdad2781-9d6b-44f4-81ed-bc36948a94db	12002	t	t	9	7	8	2023-09-18 00:00:00	t	\N	7488d78c-a873-4cec-9196-ded89ac41773
03b0d40d-ef81-452e-846d-f6bccfdbc180	e190582a-b170-45c1-a7de-d6fe5d4b5ba5	99214	f	t	8	8	7	2023-10-22 00:00:00	t	\N	7488d78c-a873-4cec-9196-ded89ac41773
93568c87-6138-4a19-9ae3-25e89f36da4e	3468b8c9-ff61-4a77-af02-f1a28d50c2c3	99213	t	f	4	3	2	2023-11-15 00:00:00	f	Lack of medical necessity	7488d78c-a873-4cec-9196-ded89ac41773
20eb86c2-90c7-4c6a-b72c-671da5a1360e	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2024-04-11 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
8d94f30d-ba8e-44ca-8753-95b8c78ab50b	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2024-04-12 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
e5e6d785-6f39-4bff-b3ef-7b43ed9256f0	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2024-04-12 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
ad163fe9-c8be-40a9-8026-2f0bb15d6679	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2024-04-11 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
d361fff7-fe9d-462d-a623-1a2d0fde8651	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	f	t	7	8	6	2024-04-14 00:00:00	t	\N	e7e0b516-e74e-4323-a086-532ede344fc0
\.


--
-- Data for Name: provider_cpt_metrics; Type: TABLE DATA; Schema: public; Owner: kishok
--

COPY public.provider_cpt_metrics (id, provider_id, cpt_code, metric, value) FROM stdin;
d03021f5-a945-4b83-9ee7-c2f03238b641	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	93306	approval_rate	100
cb82f36f-48e3-4936-932b-6c41241509fe	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	93306	submission_volume	10
5bf256e9-fe08-4886-a1cd-de7bde8f5a74	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	94321	approval_rate	100
b6214ca5-6b15-4f37-9773-1dfb66d122bd	e89048b4-3f4d-4e5c-b6e4-7a0cf21366d2	99214	cost_efficiency	60
eba4817b-d8ea-4f65-a39b-aaa07a0bd74f	a78601d4-8a0e-4961-a71e-eb2267c28934	99213	readmission_rate	2
2e7d5477-3fc4-4982-86dc-da752ace1956	0f86bdea-6a4d-46a7-99d3-98146b019384	93306	approval_rate	10
31f3877c-90c6-4579-a196-82bb453566a2	0f86bdea-6a4d-46a7-99d3-98146b019384	93306	submission_volume	1
f047ea56-5254-4d5e-be7f-0305aeaa39a9	6cfbc032-2e94-43e0-94e2-8625e1a3b5b7	93306	approval_rate	10
8b05b979-c0a3-4d60-8364-59c8cbc4fcc5	6cfbc032-2e94-43e0-94e2-8625e1a3b5b7	93306	submission_volume	1
cc5dee0a-6819-4201-a512-5c6a8ca40739	e190582a-b170-45c1-a7de-d6fe5d4b5ba5	93306	approval_rate	95
466b8968-4071-4755-b71b-8b49aa36b000	3468b8c9-ff61-4a77-af02-f1a28d50c2c3	99213	readmission_rate	1
\.


--
-- Data for Name: provider_gold_carding_status; Type: TABLE DATA; Schema: public; Owner: kishok
--

COPY public.provider_gold_carding_status (status_id, provider_id, criteria_met, gold_carding_level, valid_from, valid_until) FROM stdin;
2920a2e8-00d9-4a56-bc53-b89792ef4bff	f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	t	premier	2024-04-14 00:00:00	2024-04-14 00:00:00
\.


--
-- Data for Name: providers; Type: TABLE DATA; Schema: public; Owner: kishok
--

COPY public.providers (provider_id, name, specialty, npi_number, email, phone_number) FROM stdin;
cd7877ef-ee8d-4ed6-b4d7-7e43f6f74269	Dr. B	Endocrinology	0987654321	drb@example.com	987-654-3210
b23fd4e2-2b0c-4e36-a481-e42e8d28e456	Dr. C	General Surgery	2345678901	drc@example.com	234-567-8901
e89048b4-3f4d-4e5c-b6e4-7a0cf21366d2	Dr. D	Orthopedics	3456789012	drd@example.com	345-678-9012
a78601d4-8a0e-4961-a71e-eb2267c28934	Dr. E	Pediatrics	4567890123	dre@example.com	456-789-0123
0f86bdea-6a4d-46a7-99d3-98146b019384	Dr. F	Neurology	5678901234	drf@example.com	567-890-1234
6cfbc032-2e94-43e0-94e2-8625e1a3b5b7	Dr. G	Dermatology	6789012345	drg@example.com	678-901-2345
cdad2781-9d6b-44f4-81ed-bc36948a94db	Dr. H	Ophthalmology	7890123456	drh@example.com	789-012-3456
e190582a-b170-45c1-a7de-d6fe5d4b5ba5	Dr. I	Psychiatry	8901234567	dri@example.com	890-123-4567
3468b8c9-ff61-4a77-af02-f1a28d50c2c3	Dr. J	Rheumatology	9012345678	drj@example.com	901-234-5678
f527d6b3-eb4f-4c97-bd78-d4a86b1c42bb	Dr. A	Cardiology	1234567890	dra@example.com	123-456-7890
\.


--
-- Name: cpt_code cpt_code_code_key; Type: CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.cpt_code
    ADD CONSTRAINT cpt_code_code_key UNIQUE (code);


--
-- Name: cpt_code cpt_code_pkey; Type: CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.cpt_code
    ADD CONSTRAINT cpt_code_pkey PRIMARY KEY (id);


--
-- Name: gold_carding_criteria gold_carding_criteria_pkey; Type: CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.gold_carding_criteria
    ADD CONSTRAINT gold_carding_criteria_pkey PRIMARY KEY (criteria_id);


--
-- Name: gold_carding_evaluation_results gold_carding_evaluation_results_pkey; Type: CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.gold_carding_evaluation_results
    ADD CONSTRAINT gold_carding_evaluation_results_pkey PRIMARY KEY (evaluation_id);


--
-- Name: payer_gold_carding_eligibility payer_gold_carding_eligibility_pkey; Type: CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.payer_gold_carding_eligibility
    ADD CONSTRAINT payer_gold_carding_eligibility_pkey PRIMARY KEY (eligibility_id);


--
-- Name: payer payer_name_key; Type: CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.payer
    ADD CONSTRAINT payer_name_key UNIQUE (name);


--
-- Name: payer payer_pkey; Type: CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.payer
    ADD CONSTRAINT payer_pkey PRIMARY KEY (id);


--
-- Name: provider_cpt_approval provider_cpt_approval_pkey; Type: CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.provider_cpt_approval
    ADD CONSTRAINT provider_cpt_approval_pkey PRIMARY KEY (id);


--
-- Name: provider_cpt_metrics provider_cpt_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.provider_cpt_metrics
    ADD CONSTRAINT provider_cpt_metrics_pkey PRIMARY KEY (id);


--
-- Name: provider_gold_carding_status provider_gold_carding_status_pkey; Type: CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.provider_gold_carding_status
    ADD CONSTRAINT provider_gold_carding_status_pkey PRIMARY KEY (status_id);


--
-- Name: providers providers_pkey; Type: CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.providers
    ADD CONSTRAINT providers_pkey PRIMARY KEY (provider_id);


--
-- Name: gold_carding_criteria gold_carding_criteria_cpt_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.gold_carding_criteria
    ADD CONSTRAINT gold_carding_criteria_cpt_code_fkey FOREIGN KEY (cpt_code) REFERENCES public.cpt_code(code);


--
-- Name: gold_carding_criteria gold_carding_criteria_payer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.gold_carding_criteria
    ADD CONSTRAINT gold_carding_criteria_payer_id_fkey FOREIGN KEY (payer_id) REFERENCES public.payer(id);


--
-- Name: gold_carding_evaluation_results gold_carding_evaluation_results_criteria_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.gold_carding_evaluation_results
    ADD CONSTRAINT gold_carding_evaluation_results_criteria_id_fkey FOREIGN KEY (criteria_id) REFERENCES public.gold_carding_criteria(criteria_id);


--
-- Name: gold_carding_evaluation_results gold_carding_evaluation_results_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.gold_carding_evaluation_results
    ADD CONSTRAINT gold_carding_evaluation_results_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(provider_id);


--
-- Name: payer_gold_carding_eligibility payer_gold_carding_eligibility_cpt_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.payer_gold_carding_eligibility
    ADD CONSTRAINT payer_gold_carding_eligibility_cpt_code_fkey FOREIGN KEY (cpt_code) REFERENCES public.cpt_code(code);


--
-- Name: payer_gold_carding_eligibility payer_gold_carding_eligibility_payer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.payer_gold_carding_eligibility
    ADD CONSTRAINT payer_gold_carding_eligibility_payer_id_fkey FOREIGN KEY (payer_id) REFERENCES public.payer(id);


--
-- Name: payer_gold_carding_eligibility payer_gold_carding_eligibility_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.payer_gold_carding_eligibility
    ADD CONSTRAINT payer_gold_carding_eligibility_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(provider_id);


--
-- Name: provider_cpt_approval provider_cpt_approval_cpt_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.provider_cpt_approval
    ADD CONSTRAINT provider_cpt_approval_cpt_code_fkey FOREIGN KEY (cpt_code) REFERENCES public.cpt_code(code);


--
-- Name: provider_cpt_approval provider_cpt_approval_payer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.provider_cpt_approval
    ADD CONSTRAINT provider_cpt_approval_payer_id_fkey FOREIGN KEY (payer_id) REFERENCES public.payer(id);


--
-- Name: provider_cpt_approval provider_cpt_approval_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.provider_cpt_approval
    ADD CONSTRAINT provider_cpt_approval_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(provider_id);


--
-- Name: provider_cpt_metrics provider_cpt_metrics_cpt_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.provider_cpt_metrics
    ADD CONSTRAINT provider_cpt_metrics_cpt_code_fkey FOREIGN KEY (cpt_code) REFERENCES public.cpt_code(code);


--
-- Name: provider_cpt_metrics provider_cpt_metrics_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.provider_cpt_metrics
    ADD CONSTRAINT provider_cpt_metrics_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(provider_id);


--
-- Name: provider_gold_carding_status provider_gold_carding_status_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kishok
--

ALTER TABLE ONLY public.provider_gold_carding_status
    ADD CONSTRAINT provider_gold_carding_status_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.providers(provider_id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: kishok
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2 (Debian 16.2-1.pgdg120+2)
-- Dumped by pg_dump version 16.2 (Debian 16.2-1.pgdg120+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: kishok
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO kishok;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: kishok
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

